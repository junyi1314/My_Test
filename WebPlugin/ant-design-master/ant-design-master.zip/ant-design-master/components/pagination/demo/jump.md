# 跳转

- order: 3

快速跳转到某一页。

---

````jsx
import { Pagination } from 'antd';

ReactDOM.render(
  <Pagination showQuickJumper defaultCurrent={2} total={500} />,
 mountNode);
````
