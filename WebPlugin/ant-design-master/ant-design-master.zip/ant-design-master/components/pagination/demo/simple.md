# 简洁

- order: 6

简单地翻页。

---

````jsx
import { Pagination } from 'antd';

ReactDOM.render(
  <Pagination simple defaultCurrent={2} total={50} />,
mountNode);
````
