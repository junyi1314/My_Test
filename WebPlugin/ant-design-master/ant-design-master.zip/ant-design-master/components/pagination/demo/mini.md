# 迷你

- order: 4

迷你版本。

---

````jsx
import { Pagination } from 'antd';

ReactDOM.render(<div>
  <Pagination size="small" total={50} />
  <br />
  <Pagination size="small" total={50} showSizeChanger showQuickJumper />
</div>, mountNode);
````
