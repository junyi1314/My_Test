# 更多

- order: 1

更多分页。

---

````jsx
import { Pagination } from 'antd';

ReactDOM.render(
  <Pagination defaultCurrent={1} total={500} />,
 mountNode);
````
