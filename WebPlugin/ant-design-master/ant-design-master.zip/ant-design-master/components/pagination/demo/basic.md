# 基本

- order: 0

基础分页。

---

````jsx
import { Pagination } from 'antd';

ReactDOM.render(
  <Pagination defaultCurrent={1} total={50} />,
 mountNode);
````
