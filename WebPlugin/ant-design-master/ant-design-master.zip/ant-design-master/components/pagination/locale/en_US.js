module.exports = require('rc-pagination/lib/locale/en_US');
