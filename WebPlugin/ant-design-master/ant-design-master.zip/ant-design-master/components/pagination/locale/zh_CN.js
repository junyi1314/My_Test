module.exports = require('rc-pagination/lib/locale/zh_CN');
