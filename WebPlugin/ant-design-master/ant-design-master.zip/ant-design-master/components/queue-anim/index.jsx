import QueueAnim from 'rc-queue-anim';

export default QueueAnim;
