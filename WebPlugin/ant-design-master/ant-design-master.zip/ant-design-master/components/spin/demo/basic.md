# 基本用法

- order: 0

一个简单的 loading 状态。

---

````jsx
import { Spin } from 'antd';

ReactDOM.render(
  <Spin />
, mountNode);
````
