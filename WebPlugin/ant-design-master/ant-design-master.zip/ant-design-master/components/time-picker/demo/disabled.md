# 禁用

-	order: 4

禁用时间选择。

---

````jsx
import { TimePicker } from 'antd';

ReactDOM.render(
  <TimePicker defaultValue="12:08:23" disabled />
, mountNode);
````
