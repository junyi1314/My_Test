# 基本

- order: 0

最简单的用法，适用于简短的警告提示。

---

````jsx
import { Alert } from 'antd';

ReactDOM.render(<Alert message="成功提示的文案" type="success" />
, mountNode);
````
