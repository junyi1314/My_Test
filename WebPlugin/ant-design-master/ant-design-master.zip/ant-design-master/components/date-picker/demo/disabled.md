# 禁用

- order: 5

选择框的不可用状态。

---

````jsx
import { DatePicker } from 'antd';

ReactDOM.render(
  <DatePicker defaultValue="2015-06-06" disabled />
, mountNode);
````
