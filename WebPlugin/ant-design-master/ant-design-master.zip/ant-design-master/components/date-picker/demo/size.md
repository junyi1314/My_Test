# 三种大小

- order: 1

三种大小的输入框，大的用在表单中，中的为默认。

---

````jsx
import { DatePicker } from 'antd';

ReactDOM.render(
  <div>
    <DatePicker size="large" />
    <DatePicker />
    <DatePicker size="small" />
  </div>
, mountNode);
````
