# 各种类型

四种颜色的标签。

- order: 1

---

````jsx
import { Tag } from 'antd';

ReactDOM.render(<div>
  <Tag closable color="blue">蓝色</Tag>
  <Tag closable color="green">绿色</Tag>
  <Tag closable color="yellow">黄色</Tag>
  <Tag closable color="red">红色</Tag>
</div>, mountNode);
````

