# 两种大小

- order: 3

`size="small"` 表示小号开关。

---

````jsx
import { Switch } from 'antd';

ReactDOM.render(
  <div>
    <Switch />
    &nbsp;
    <Switch size="small" />
  </div>
, mountNode);
````
