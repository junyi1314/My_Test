import AntRadio from './radio';
import Group from './group';
import Button from './radioButton';

AntRadio.Button = Button;
AntRadio.Group = Group;
export default AntRadio;
