# 基本

- order: 0

最简单的用法。

---

````jsx
import { Radio } from 'antd';

ReactDOM.render(<Radio>Radio</Radio>
, mountNode);
````
