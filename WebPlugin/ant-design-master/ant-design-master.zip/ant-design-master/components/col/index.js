import { Col } from '../layout';
export default Col;
