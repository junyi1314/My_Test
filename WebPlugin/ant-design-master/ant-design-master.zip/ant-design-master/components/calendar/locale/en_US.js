module.exports = require('../../date-picker/locale/en_US');
