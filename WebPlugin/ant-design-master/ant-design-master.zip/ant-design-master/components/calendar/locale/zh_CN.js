module.exports = require('../../date-picker/locale/zh_CN');
