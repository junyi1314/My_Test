import Validation from 'rc-form-validation';

export default Validation;
