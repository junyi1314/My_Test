# 基本

- order: 0

最简单的用法。

---

````jsx
import { Affix, Button } from 'antd';

ReactDOM.render(
  <Affix>
    <Button type="primary">固定在顶部</Button>
  </Affix>
, mountNode);
````
