# 自动切换

- order: 3

定时切换下一张。

---

````jsx
import { Carousel } from 'antd';

ReactDOM.render(
  <Carousel autoplay="true">
    <div><h3>1</h3></div>
    <div><h3>2</h3></div>
    <div><h3>3</h3></div>
    <div><h3>4</h3></div>
  </Carousel>
, mountNode);
````

