# 基本

- order: 0

最简单的用法。

---

````jsx
import { Tooltip } from 'antd';

ReactDOM.render(
  <Tooltip title="提示文字">
    <span>鼠标移上来就会出现提示</span>
  </Tooltip>
, mountNode);
````

