# 设计模式

- category: 模式
- disabled: true

---

敬请期待。

